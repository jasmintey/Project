<div id="banner"><img src="images/banner.jpg" alt="Paris" class="center"></div>
<div class="topnav">
<a href="logcall.php">Log Call</a>
<a href="update.php">Update</a>
<a href="#">Report</a>
<a href="#">History</a>
</div>